def llamar_modulo():
    print('Estamos usando el modulo 2')
    