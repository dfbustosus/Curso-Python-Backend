from setuptools import setup 

setup(
    name="Paquete_prueba",
    version="1.1",
    description="Primer paquete dist",
    author="David",
    author_email="dafbustosus@unal.edu.co",
    packages=['Paquete_prueba']
)

# python setup.py sdist
# cd dist
# pip install paquete_1-1.0.tar.gz
