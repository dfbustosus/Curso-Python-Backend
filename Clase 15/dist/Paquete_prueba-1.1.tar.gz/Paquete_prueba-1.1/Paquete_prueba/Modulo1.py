def minusculas(texto):
    var= texto.lower() 
    return var

def remueva_espacios(text):
    var= text.strip().lstrip().rstrip() 
    return var 

def mayusculas(texto):
    var= len(texto.upper())
    return var

def capitalizar(texto):
    de= texto.capitalize()
    return de